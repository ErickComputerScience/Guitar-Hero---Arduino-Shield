#include <TimerOne.h>
#include <MultiFuncShield.h>

// ===============================
// VARIÁVEIS DO JOGO
// ===============================

int ledAtual = 0;
int vidas = 3;

bool jogoIniciado = false;
bool jogoFinalizado = false;
bool ledAtivo = false;

int tempoInicial = 30;
int tempoRestante = 30;

unsigned long ultimoSegundo = 0;
unsigned long tempoLedLigado = 0;

int tempoResposta = 1000; // ms para responder

// ===============================
// GERA LED ALEATÓRIO
// ===============================

void gerarNovoLed()
{
  ledAtual = random(1, 5);

  MFS.writeLeds(LED_ALL, OFF);

  switch(ledAtual)
  {
    case 1:
      MFS.writeLeds(LED_1, ON);
      break;

    case 2:
      MFS.writeLeds(LED_2, ON);
      break;

    case 3:
      MFS.writeLeds(LED_3, ON);
      break;

    case 4:
      MFS.writeLeds(LED_4, ON);
      break;
  }

  tempoLedLigado = millis();
  ledAtivo = true;
}

// ===============================
// GAME OVER
// ===============================

void tocarDerrota()
{
  MFS.write("0000");

  while(true)
  {
    MFS.writeLeds(LED_ALL, ON);
    MFS.beep(10, 10, 1);

    delay(200);

    MFS.writeLeds(LED_ALL, OFF);

    delay(200);
  }
}

// ===============================
// VITÓRIA
// ===============================

void tocarVitoria()
{
  MFS.write("WIN");

  for(int i = 0; i < 3; i++)
  {
    MFS.beep(100, 100, 1);
    delay(250);
  }

  while(true);
}

// ===============================
// VERIFICA BOTÃO
// ===============================

void verificarEntrada(int botao)
{
  if(botao == ledAtual)
  {
    MFS.beep();

    // aumenta a dificuldade
    if(tempoResposta > 300)
      tempoResposta -= 20;

    gerarNovoLed();
  }
  else
  {
    vidas--;

    Serial.print("Errou! Vidas restantes: ");
    Serial.println(vidas);

    MFS.beep(50, 50, 2);

    if(vidas <= 0)
    {
      jogoFinalizado = true;
      tocarDerrota();
    }
  }
}

// ===============================
// VERIFICA TEMPO LIMITE DO LED
// ===============================

void verificarTimeout()
{
  if(ledAtivo &&
     millis() - tempoLedLigado >= tempoResposta)
  {
    vidas--;

    Serial.print("Tempo esgotado! Vidas restantes: ");
    Serial.println(vidas);

    MFS.beep(100, 100, 2);

    if(vidas <= 0)
    {
      jogoFinalizado = true;
      tocarDerrota();
    }

    gerarNovoLed();
  }
}

// ===============================
// SETUP
// ===============================

void setup()
{
  Timer1.initialize();
  MFS.initialize();

  randomSeed(analogRead(A0));

  Serial.begin(9600);
}

// ===============================
// LOOP
// ===============================

void loop()
{
  // ============================
  // TELA INICIAL
  // ============================

  if(!jogoIniciado)
  {
    int valorPot = analogRead(A0);

    tempoInicial = map(valorPot, 0, 1023, 10, 90);

    tempoRestante = tempoInicial;

    MFS.write(tempoInicial);

    byte botao = MFS.getButton();

    if(botao)
    {
      byte acao = botao & B11000000;

      if(acao == BUTTON_PRESSED_IND)
      {
        jogoIniciado = true;

        MFS.write("GO");

        MFS.beep();

        delay(1000);

        gerarNovoLed();

        ultimoSegundo = millis();
      }
    }

    return;
  }

  if(jogoFinalizado)
    return;

  // ============================
  // CRONÔMETRO
  // ============================

  if(millis() - ultimoSegundo >= 1000)
  {
    ultimoSegundo = millis();

    tempoRestante--;

    MFS.write(vidas);

    Serial.print("Tempo: ");
    Serial.print(tempoRestante);
    Serial.print(" s | Vidas: ");
    Serial.println(vidas);

    if(tempoRestante <= 0)
    {
      jogoFinalizado = true;
      tocarVitoria();
    }
  }

  // ============================
  // TEMPO LIMITE DO LED
  // ============================

  verificarTimeout();

  // ============================
  // LEITURA DOS BOTÕES
  // ============================

  byte botao = MFS.getButton();

  if(botao)
  {
    byte numero = botao & B00111111;
    byte acao = botao & B11000000;

    if(acao == BUTTON_PRESSED_IND)
    {
      verificarEntrada(numero);

      delay(100);
    }
  }
}