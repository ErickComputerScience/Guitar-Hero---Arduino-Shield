#include <TimerOne.h>
#include <MultiFuncShield.h>
#include <SoftwareSerial.h>

// ===============================
// BLUETOOTH
// ===============================
SoftwareSerial BT(10, 11); // RX, TX

// ===============================
// VARIÁVEIS DO JOGO
// ===============================

int ledAtual = 0;
int vidas = 3;
int score = 0;

bool jogoIniciado = false;
bool jogoFinalizado = false;
bool ledAtivo = false;

int tempoInicial = 30;
int tempoRestante = 30;

unsigned long ultimoSegundo = 0;
unsigned long tempoLedLigado = 0;

int tempoResposta = 1000;

// ===============================
// ENVIA DADOS PARA BLUETOOTH
// ===============================
void enviarBluetooth()
{
  BT.print("S:");
  BT.print(score);
  BT.print(" V:");
  BT.print(vidas);
  BT.print(" T:");
  BT.println(tempoRestante);
}

// ===============================
// GERA LED ALEATÓRIO
// ===============================

void gerarNovoLed()
{
  ledAtual = random(1, 5);

  MFS.writeLeds(LED_ALL, OFF);

  switch(ledAtual)
  {
    case 1: MFS.writeLeds(LED_1, ON); break;
    case 2: MFS.writeLeds(LED_2, ON); break;
    case 3: MFS.writeLeds(LED_3, ON); break;
    case 4: MFS.writeLeds(LED_4, ON); break;
  }

  tempoLedLigado = millis();
  ledAtivo = true;

  enviarBluetooth();
}

// ===============================
// GAME OVER
// ===============================

void tocarDerrota()
{
  MFS.write("0000");

  BT.println("GAME OVER");

  while(true)
  {
    MFS.writeLeds(LED_ALL, ON);
    MFS.beep(10, 10, 1);
    delay(200);

    MFS.writeLeds(LED_ALL, OFF);
    delay(200);
  }
}

// ===============================
// VITÓRIA
// ===============================

void tocarVitoria()
{
  MFS.write("WIN");

  BT.println("WIN");

  for(int i = 0; i < 3; i++)
  {
    MFS.beep(100, 100, 1);
    delay(250);
  }

  while(true);
}

// ===============================
// VERIFICA ENTRADA
// ===============================

void verificarEntrada(int botao)
{
  if(botao == ledAtual)
  {
    MFS.beep();

    score++; // 🔵 AUMENTA PONTUAÇÃO

    if(tempoResposta > 300)
      tempoResposta -= 20;

    gerarNovoLed();
  }
  else
  {
    vidas--;

    BT.println("ERRO");

    MFS.beep(50, 50, 2);

    if(vidas <= 0)
    {
      jogoFinalizado = true;
      tocarDerrota();
    }
  }

  enviarBluetooth();
}

// ===============================
// TIMEOUT DO LED
// ===============================

void verificarTimeout()
{
  if(ledAtivo &&
     millis() - tempoLedLigado >= tempoResposta)
  {
    vidas--;

    BT.println("TIMEOUT");

    MFS.beep(100, 100, 2);

    if(vidas <= 0)
    {
      jogoFinalizado = true;
      tocarDerrota();
    }

    gerarNovoLed();
  }
}

// ===============================
// SETUP
// ===============================

void setup()
{
  Timer1.initialize();
  MFS.initialize();

  Serial.begin(9600);   // USB
  BT.begin(9600);       // Bluetooth

  randomSeed(analogRead(A0));
}

// ===============================
// LOOP
// ===============================

void loop()
{
  // ============================
  // TELA INICIAL
  // ============================

  if(!jogoIniciado)
  {
    int valorPot = analogRead(A0);

    tempoInicial = map(valorPot, 0, 1023, 10, 90);
    tempoRestante = tempoInicial;

    MFS.write(tempoInicial);

    byte botao = MFS.getButton();

    if(botao)
    {
      byte acao = botao & B11000000;

      if(acao == BUTTON_PRESSED_IND)
      {
        jogoIniciado = true;

        MFS.write("GO");
        BT.println("START");

        MFS.beep();

        delay(1000);

        gerarNovoLed();
        ultimoSegundo = millis();

        enviarBluetooth();
      }
    }

    return;
  }

  if(jogoFinalizado)
    return;

  // ============================
  // CRONÔMETRO
  // ============================

  if(millis() - ultimoSegundo >= 1000)
  {
    ultimoSegundo = millis();
    tempoRestante--;

    MFS.write(tempoRestante);

    enviarBluetooth();

    if(tempoRestante <= 0)
    {
      jogoFinalizado = true;
      tocarVitoria();
    }
  }

  // ============================
  // TIMEOUT LED
  // ============================

  verificarTimeout();

  // ============================
  // BOTÕES
  // ============================

  byte botao = MFS.getButton();

  if(botao)
  {
    byte numero = botao & B00111111;
    byte acao = botao & B11000000;

    if(acao == BUTTON_PRESSED_IND)
    {
      verificarEntrada(numero);
      delay(100);
    }
  }
}